import streamlit as st
import yfinance as yf
import pandas as pd
import numpy as np
import quantstats as qs
from io import BytesIO

st.set_page_config(page_title="S&P 500 Stock Screener", layout="wide")
st.title("📈 S&P 500 Stock Screener with Growth, Value, Risk Metrics")

@st.cache_data(show_spinner=False)
def get_sp500_tickers():
    url = 'https://en.wikipedia.org/wiki/List_of_S%26P_500_companies'
    tables = pd.read_html(url)
    return tables[0]['Symbol'].tolist()

@st.cache_data(show_spinner=False)
def get_metrics(ticker):
    try:
        stock = yf.Ticker(ticker)
        info = stock.info

        pe_ratio = info.get("trailingPE", np.nan)
        eps_growth = info.get("earningsQuarterlyGrowth", np.nan)
        rev_growth = info.get("revenueGrowth", np.nan)
        free_cashflow = info.get("freeCashflow", 0)
        total_assets = info.get("totalAssets", 1)
        croci = (free_cashflow / total_assets) * 100 if total_assets else np.nan

        hist = stock.history(period='1y')['Close']
        if hist.empty or hist.isna().sum() > 10:
            return None

        returns = hist.pct_change().dropna()
        sortino = qs.stats.sortino(returns)
        alpha = qs.stats.alpha(returns)

        return {
            'Ticker': ticker,
            'P/E': pe_ratio,
            'EPS Growth': eps_growth,
            'Revenue Growth': rev_growth,
            'CROCI %': croci,
            'Sortino': sortino,
            'Alpha': alpha
        }
    except:
        return None

def to_excel(df):
    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False)
    return output.getvalue()

if st.button("Run S&P 500 Scanner"):
    tickers = get_sp500_tickers()
    results = []
    with st.spinner("Scanning S&P 500... this can take a few minutes."):
        for ticker in tickers:
            data = get_metrics(ticker)
            if data:
                results.append(data)
    if results:
        df = pd.DataFrame(results)
        filtered = df[
            (df['P/E'] < 25) &
            (df['EPS Growth'] > 0.10) &
            (df['Revenue Growth'] > 0.10) &
            (df['Sortino'] > 1.5) &
            (df['Alpha'] > 0.02) &
            (df['CROCI %'] > 10)
        ].sort_values(by='CROCI %', ascending=False)
        
        st.success(f"Found {len(filtered)} matching stocks.")
        st.dataframe(filtered, use_container_width=True)
        
        excel_data = to_excel(filtered)
        st.download_button("📥 Download Excel", excel_data, file_name="sp500_stock_scan.xlsx")
    else:
        st.warning("No stocks matched your criteria.")

else:
    st.info("Click the button above to scan the S&P 500.")
