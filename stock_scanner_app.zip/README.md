# S&P 500 Stock Screener

This is a Streamlit app that scans the entire S&P 500 for stocks matching criteria for value, growth, risk, and CROCI.

## How to Deploy

1. Upload `streamlit_app.py` and `requirements.txt` to a GitHub repository.
2. Deploy the app on [Streamlit Cloud](https://streamlit.io/cloud).
3. Run the app from the link provided by Streamlit Cloud.

## Features

- Scans S&P 500 automatically
- Filters stocks by:
  - P/E ratio < 25
  - EPS Growth > 10%
  - Revenue Growth > 10%
  - Sortino Ratio > 1.5
  - Alpha > 0.02
  - CROCI > 10%
- Download filtered stocks as Excel
